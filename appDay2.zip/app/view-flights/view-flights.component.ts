import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ViewDetailsService } from '../view-details/view-details.service';
/* Import the required modules here */ 

@Component({
  selector: 'app-view-flights',
  templateUrl: './view-flights.component.html',
  styleUrls: ['./view-flights.component.css']
})

export class ViewFlightsComponent implements OnInit {
  flightDetails;

  @Output() flightToEmit = new EventEmitter();

  imageUrl = ["../../assets/a1.jpg", "../../assets/a2.jpg", "../../assets/a3.jpg"];
  errorMessage = null;
  isDisabled=[];

  /* Inject the required dependency here */
  constructor(private viewDetailsService:ViewDetailsService) { }

  ngOnInit() { this.getAllFlights();
}

  getAllFlights() {
    // implement the getAllFlights method by invoking the view method of ViewDetailsService
    // and correspondingly populate flightDetails and errorMessage
     this.viewDetailsService.view().subscribe(value=>{this.flightDetails=value;
      this.flightDetails.forEach(element => {
        if(element.status=="Cancelled"||element.availableSeats==0)
        this.isDisabled.push(true);
        else
        this.isDisabled.push(false);
      });
      },
      (err=>{this.errorMessage=err.error.message}))
  }

  sendFlightData(flight) {
    // emit the flight object using the flightToEmit event
    this.flightToEmit.emit(flight);
  }

}
