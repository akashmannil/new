import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlightBooking } from '../shared/FlightBooking';
import { Observable } from 'rxjs';

@Injectable()
export class ViewDetailsService {

  booking: Observable<FlightBooking[]>
  _getAllBookingsURL = "http://localhost:1050/getAllBookings"
  _deleteURL = "http://localhost:1050/delete/"

  /* Inject the required dependencies here */ 
  constructor(private http:HttpClient) { }
  // view(): Observable<FlightBooking[]> {
  view(): Observable<any> {
    //make an http GET request with the URL _getAllBookingsURL
    return this.http.get(this._getAllBookingsURL)
  }

  delete(bookingId): Observable<any> {
    //make an http DELETE request with the url _deleteURL with bookingId as route parameter
    return this.http.delete(this._deleteURL+bookingId);
  }
}
