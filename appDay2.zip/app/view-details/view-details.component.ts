import { Component, OnInit } from '@angular/core';
import { ViewDetailsService } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';
import { Flights } from '../shared/Flight';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {
  custId: string
  flightId: string
  bookings: Flights[] = []
  flightDetails: FlightBooking[];
  filt=true;
  errorMessage: String;
  flights: Flights[];

  /* Inject the required dependencies here */ 
  constructor(private vds:ViewDetailsService) { }

  ngOnInit() { this.viewAllBookings();}


  viewAllBookings() {
    // implement the viewAllBookings method by invoking the view method of ViewDetailsService
    // and correspondingly populate flightDetails and errorMessage 
    this.vds.view().subscribe(val=>{
      this.flightDetails=val;
      this.flightDetails.forEach(ele=>{
        ele.bookings.forEach(b=>{
          b.flightId=ele.flightId;
          this.bookings.push(b);
        })
      })
      this.flights=this.bookings;
      console.log(this.bookings,":",this.flights)
    },err=>{this.errorMessage=err.error.message})
  }

}