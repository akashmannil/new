import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UpdateBookingService } from './update-booking.service';
/* Import the required modules here */ 

@Component({
  selector: 'app-update-booking',
  templateUrl: './update-booking.component.html',
  styleUrls: ['./update-booking.component.css']
})
export class UpdateBookingComponent implements OnInit {

  bookingId: number;
  flightId: string;
  successMessage: string;
  errorMessage: string;
  updateBookingForm: FormGroup;

  /* Inject the required dependencies here */
  constructor(private fb:FormBuilder,private ar:ActivatedRoute,
    private ubs:UpdateBookingService) { }
  
  ngOnInit() {
    // Fetch the values from route parameters
    // code the updateBookingForm with mentioned requirements
    this.ar.params.subscribe(param=>{
      this.bookingId=param.bookingId;
      this.flightId=param.flightId;
      this.updateBookingForm=this.fb.group({
        bookingId:[{value:this.bookingId,disabled:true},[Validators.required,Validators.min(2001)]],
        noOfTickets:['',[Validators.required,Validators.min(1)]],
        flightId:[{value:this.flightId,disabled:true},Validators.required]
      })
    })
  }

  updateBooking() {
    // Implement the updateBooking method by invoking the updateBooking method of UpdateBookingService
    // and correspondingly populate errorMessage and successMessage 
    this.successMessage=null;
    this.errorMessage=null;
    console.log(this.updateBookingForm)
    this.ubs.updateBooking(this.updateBookingForm.value).subscribe(val=>{this.successMessage=val.message;
    console.log(this.successMessage)},
      err=>this.errorMessage=err.error.message)
  }
}

