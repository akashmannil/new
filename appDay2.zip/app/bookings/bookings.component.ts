import { Component, OnInit, Input } from '@angular/core';
import { ViewDetailsService } from '../view-details/view-details.service';
import { Router } from '@angular/router';
/* Import all the necessary modules here */ 

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {
  @Input() bookingDetails;
  successMessage = null
  errorMessage = null

  /* Inject the required Dependencies Here */
  constructor(private vds:ViewDetailsService,private router:Router) { }

  ngOnInit() { }

  delete(bookingId) {
    // implement the delete method by invoking the delete method of ViewDetailsService
    // and correspondingly populate errorMessage, successMessage and bookingDetails
    this.vds.delete(bookingId).subscribe(val=>{
      this.successMessage=val;
      this.bookingDetails=this.bookingDetails.filter(val=>val.bookingId!=bookingId);
    },err=>{
      this.errorMessage=err.error.message;
    })
  }

  updateBooking(booking) {
    // use the router instance and navigate to UpdateComponent 
    // by passing bookingId and flightId og booking object
    this.router.navigate(['/updateBooking',booking.bookingId,booking.flightId]);
  }

}
