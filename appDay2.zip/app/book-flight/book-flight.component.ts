import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";
/* Import the required modules here */ 

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {
  flightDetails
  errorMessage: String;
  successMessage: String;
  bookingForm: FormGroup
  isDisabled=true;
  /* Inject the required dependencies here */
  constructor(private fb:FormBuilder,private bfs:BookFlightService) { }

  ngOnInit() { }

  showForm(flight) {
    this.isDisabled=!this.isDisabled;
    console.log(flight);
    // populate flightDetails with flight
    //code the bookingForm with all mentioned validations
    this.flightDetails=flight;
    this.bookingForm=this.fb.group({
      passengerName:['',[Validators.required,Validators.pattern(/^[A-Za-z\ ]*$/)]],
      noOfTickets:['',[Validators.required,Validators.min(1)]],
      flightId:[{value:flight.flightId,disabled:true}],
      customerId:['',[Validators.required,this.validateCustomerId]]
    })
    console.log("asd",this.bookingForm.value)
  }

  book() {
    // implement the book method by invoking the bookFlight method of BookFlightService
    // and correspondingly populate errorMessage and successMessage 
    this.successMessage=null;
    this.errorMessage=null;
    this.bookingForm.value.flightId=this.flightDetails.flightId;
    this.bfs.bookFlight(this.bookingForm.value).subscribe(val=>{
      this.successMessage=val.message;
    },
      err=>{this.errorMessage=err.error.message})
  }

  validateCustomerId(c: FormControl) {
    // implement a custom validator to validate customerId and populate customerIdErr object with message 
    console.log(c,":","myvalue");
    if(!/^[A-Z][1-9][0-9]{3}$/.test(c.value)){
      return {customerIdErr:{message:"Enter a valid Customer Id (E.g., R1001)"}};
    }
    return null;
  }
}



