import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'flightId'
})
export class FlightIdPipe implements PipeTransform {

  transform(value: any, flightId: any): any {
    // filter the bookings array based on flightId
    console.log(value,":",flightId)
    let myval=[]
    value.forEach(element => {
      console.log(element)
      if(element.flightId==flightId)
      myval.push(element);
    });
    console.log(myval);
    return myval;
    
  }

}
