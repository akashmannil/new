import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customerId'
})
export class CustomerIdPipe implements PipeTransform {

  transform(value: any, customerId: any): any {
    // filter the bookings array based on customerId
    let myval=[]
    value.forEach(element => {
      if(element.customerId==customerId)
      myval.push(element);
    });
    console.log(myval);
    return myval;
  }


}
